# Basic 



```sh
terraform init
terraform plan
terraform apply
```